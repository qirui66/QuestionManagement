package com.imut.Utils;

import java.util.ArrayList;
import java.util.List;

import com.imut.dao.question.QuestionDaoImpl;
import com.imut.pojo.Question;

public class Analyze {

	public static List<String> analyzing(String info) {
		List<String> list = new ArrayList<String>();
		String[] tt = info.split("\\s+");
		for (String s:tt) 
			list.add(s);
		return list;
	}
	
	public static List<Question> subAnalyze(List<String> list) {
		List<Question> qList = new ArrayList<Question>();
		for (String str : list) {
	        int index = 3;
	        String type = str.substring(0,index);
	        System.out.println(type);
	        int i = index;
	        while (i < str.length()) {
	        	qList.add(new QuestionDaoImpl().getQuestionBy(Integer.parseInt(str.substring(i, i + 5))));
	            i += 5;
	        }
		}
        return qList;
	}
}
