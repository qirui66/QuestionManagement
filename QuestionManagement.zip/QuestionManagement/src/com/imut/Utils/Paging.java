package com.imut.Utils;

public class Paging {
	public static final int pageSize = 10;
	
	public static int pageCal(int nowPage,int count) {
		if (nowPage < 1) 
			return 0;
		int maxPage = 0;
		if (count % pageSize != 0)
			maxPage = count / pageSize + 1;
		else
			maxPage = count / pageSize;
		if (nowPage > maxPage)
			return (maxPage-1) * pageSize;
		return (nowPage-1) * pageSize;
	}
}
