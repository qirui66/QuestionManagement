package com.imut.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomUtils {

	public static List<Integer> product(int num, int min, int max) {
		Random r = new Random();
		List<Integer> array = new ArrayList<Integer>();
		int y = 0;
		
		while (y < num) {
			int number = r.nextInt(max) + min;
			System.out.println(number);
			if (!array.contains(number)) {
				array.add(number);
				y++;
			}
		}
		return array;
	}
	
	public static String push(String type, List<Integer> array ) {
		String str = type;
		for (Integer i : array) {
			str += i;
		}
		str += " ";
		System.out.println(str);
		return str;
	}
}
