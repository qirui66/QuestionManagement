package com.imut.service.course;

import java.util.List;

import com.imut.Utils.Paging;
import com.imut.dao.course.CourseDao;
import com.imut.dao.course.CourseDaoImpl;
import com.imut.dao.paper.PaperDaoImpl;
import com.imut.dao.question.QuestionDaoImpl;
import com.imut.pojo.Course;

public class CourseServiceImpl implements CourseService{
	public static CourseDao courseDao;

	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		return courseDao.getCourseById(courseId);
	}

	public int getCourseCounts() {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		return courseDao.getCourseCounts();
	}

	public List<Course> getCourseByName(String courseName, int index) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		int count = courseDao.getCourseCounts();
		return courseDao.getCourseByName(courseName, Paging.pageCal(index, count));
	}

	public List<Course> allCourses(int index) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		int count = courseDao.getCourseCounts();
		return courseDao.allCourses(Paging.pageCal(index, count));
	}

	public int addCourse(Course course) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		return courseDao.addCourse(course);
	}

	public int deleteCourse(int courseId) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		new QuestionDaoImpl().deleteQuestionByCourse(courseDao.getCourseById(courseId).getCourseName());
		new PaperDaoImpl().deletePaperByName(courseDao.getCourseById(courseId).getCourseName());
		return courseDao.deleteCourse(courseId);
	}

	public int updateCourse(Course course) {
		// TODO Auto-generated method stub
		courseDao = new CourseDaoImpl();
		return courseDao.updateCourse(course);
	}
	
}
