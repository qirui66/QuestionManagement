package com.imut.service.type;

import java.util.List;

import com.imut.dao.question.QuestionDao;
import com.imut.dao.question.QuestionDaoImpl;
import com.imut.dao.type.TypeDao;
import com.imut.dao.type.TypeDaoImpl;
import com.imut.pojo.QuestionType;

public class TypeServiceImpl implements TypeService{

	public static TypeDao typeDao;
	
	public List<QuestionType> allTypes() {
		// TODO Auto-generated method stub
		typeDao = new TypeDaoImpl();
		return typeDao.allTypes();
	}

	public int addType(QuestionType type) {
		// TODO Auto-generated method stub
		typeDao = new TypeDaoImpl();
		return typeDao.addType(type);
	}

	public int deleteType(int typeId) {
		// TODO Auto-generated method stub
		typeDao = new TypeDaoImpl();
		QuestionDao questionDao = new QuestionDaoImpl();
		if (questionDao.getQuestionByType(typeDao.getTypeById(typeId).getTypeName(), 0) != null)
			return 0;
		return typeDao.deleteType(typeId);
	}

	public int updateType(QuestionType type) {
		// TODO Auto-generated method stub
		typeDao = new TypeDaoImpl();
		return typeDao.updateType(type);
	}

	public QuestionType getTypeById(int typeId) {
		// TODO Auto-generated method stub
		typeDao = new TypeDaoImpl();
		return typeDao.getTypeById(typeId);
	}

}
