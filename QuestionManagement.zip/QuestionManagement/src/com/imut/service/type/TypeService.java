package com.imut.service.type;

import java.util.List;

import com.imut.pojo.QuestionType;

public interface TypeService {
	
	QuestionType getTypeById(int typeId);
	
	List<QuestionType> allTypes();
	
	int addType(QuestionType type);
	
	int deleteType(int typeId);
	
	int updateType(QuestionType type);
}
