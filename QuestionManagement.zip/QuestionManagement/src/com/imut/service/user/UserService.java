package com.imut.service.user;

import java.util.List;

import com.imut.pojo.User;

public interface UserService {

	User getUser(String account);
	
	User getUserById(int id);
	
	List<User> allUsers(int pageNum);
	
	int addUser(User user);
	
	int deleteUser(int id);
	
	int updateUser(User user);
	
	List<User> getUsersByName(String name,int pageNum);
	
	List<User> getUsersByAccount(String account,int pageNum);
	
	List<User> getUsersByIdentity(String identity,int pageNum);
	
	int getUserCounts();
}
