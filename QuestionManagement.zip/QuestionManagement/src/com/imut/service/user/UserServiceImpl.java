package com.imut.service.user;

import java.util.List;

import com.imut.Utils.Paging;
import com.imut.dao.user.UserDao;
import com.imut.dao.user.UserDaoImpl;
import com.imut.pojo.User;

public class UserServiceImpl implements UserService{
	
	public static UserDao userDao;

	public User getUser(String account) {
		userDao = new UserDaoImpl();
		User user = userDao.getUser(account);
		return user;
	}

	public List<User> allUsers(int pageNum) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		int count = userDao.getUserCounts();
		return userDao.allUsers(Paging.pageCal(pageNum, count));
	}

	public int addUser(User user) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		return userDao.addUser(user);
	}

	public int deleteUser(int id) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		return userDao.deleteUser(id);
	}

	public int updateUser(User user) {
		userDao = new UserDaoImpl();
		return userDao.updateUser(user);
	}

	public List<User> getUsersByName(String name, int pageNum) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		int count = userDao.getUserCounts();
		return userDao.getUsersByName(name, Paging.pageCal(pageNum, count));
	}

	public List<User> getUsersByAccount(String account, int pageNum) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		int count = userDao.getUserCounts();
		return userDao.getUsersByAccount(account, Paging.pageCal(pageNum, count));
	}

	public List<User> getUsersByIdentity(String identity, int pageNum) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		int count = userDao.getUserCounts();
		return userDao.getUsersByIdentity(identity, Paging.pageCal(pageNum, count));
	}

	public User getUserById(int id) {
		// TODO Auto-generated method stub
		userDao = new UserDaoImpl();
		return userDao.getUserById(id);
	}

	public int getUserCounts() {
		userDao = new UserDaoImpl();
		return userDao.getUserCounts();
	}

}
