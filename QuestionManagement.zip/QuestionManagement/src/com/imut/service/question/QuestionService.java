package com.imut.service.question;

import java.util.List;

import com.imut.pojo.Question;

public interface QuestionService {

	int getQuestionCounts(String type);
	
	Question getQuestionBy(int qid);
	
	List<Question> getQuestionByType(String type,int index);
	
	List<Question> getQuestionByName(String questionName,int index);
	
	List<Question> getQuestionByCourse(String courseName,int index);
	
	List<Question> allQuestion(int index);
	
	int addQuestion(Question question);
	
	int deleteQuestion(int qid);
	
	int deleteQuestionByCourse(String courseName);
	
	int updateQuestion(Question question);
}
