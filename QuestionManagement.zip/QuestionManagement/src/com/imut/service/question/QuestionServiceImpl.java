package com.imut.service.question;

import java.util.List;

import com.imut.Utils.Paging;
import com.imut.dao.question.QuestionDao;
import com.imut.dao.question.QuestionDaoImpl;
import com.imut.pojo.Question;

public class QuestionServiceImpl implements QuestionService{

	public static QuestionDao questionDao;

	public int getQuestionCounts(String type) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.getQuestionCounts(type);
	}

	public List<Question> getQuestionByType(String type, int index) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		int count = questionDao.getQuestionCounts(type);
		if (type.equals("选择题") || type.equals("判断题") || type.equals("简答题"))
			return questionDao.getQuestionByType(type, Paging.pageCal(index, count));
		return questionDao.allQuestion(0);
	}

	public List<Question> getQuestionByName(String questionName, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Question> getQuestionByCourse(String courseName, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Question> allQuestion(int index) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.allQuestion(0);
	}

	public int addQuestion(Question question) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.addQuestion(question);
	}

	public int deleteQuestion(int qid) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.deleteQuestion(qid);
	}

	public int deleteQuestionByCourse(String courseName) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateQuestion(Question question) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.updateQuestion(question);
	}

	public Question getQuestionBy(int qid) {
		// TODO Auto-generated method stub
		questionDao = new QuestionDaoImpl();
		return questionDao.getQuestionBy(qid);
	}

	
}
