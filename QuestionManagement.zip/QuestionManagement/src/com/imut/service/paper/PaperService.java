package com.imut.service.paper;

import java.util.List;

import com.imut.pojo.Paper;
import com.imut.pojo.Question;

public interface PaperService {
	
	Paper getPaperById(int paperId);
	
	List<Paper> getPaperByName(String paperName);
	
	List<Paper> allPapers();
	
	int addPaper(List<String> paramList);
	
	int deletePaper(int paperId);
	
	List<Question> getPaperQuestion(int paperId);
}
