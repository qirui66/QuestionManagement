package com.imut.service.paper;

import java.util.List;

import com.imut.Utils.Analyze;
import com.imut.Utils.RandomUtils;
import com.imut.dao.paper.PaperDao;
import com.imut.dao.paper.PaperDaoImpl;
import com.imut.pojo.Paper;
import com.imut.pojo.Question;
import com.imut.service.question.QuestionServiceImpl;

public class PaperServiceImpl implements PaperService{
	
	public static PaperDao paperDao;

	public Paper getPaperById(int paperId) {
		// TODO Auto-generated method stub
		paperDao = new PaperDaoImpl();
		return paperDao.getPaperById(paperId);
	}

	public List<Paper> getPaperByName(String paperName) {
		// TODO Auto-generated method stub
		paperDao = new PaperDaoImpl();
		return paperDao.getPaperByName(paperName);
	}

	public List<Paper> allPapers() {
		// TODO Auto-generated method stub
		paperDao = new PaperDaoImpl();
		return paperDao.allPapers();
	}

	public int addPaper(List<String> paramList) {
		// TODO Auto-generated method stub
		int paperId = Integer.parseInt(paramList.get(0));
		String paperName = paramList.get(1);
		String paperCourse = paramList.get(2);
		Paper paper = new Paper();
		int choiceNum = Integer.parseInt(paramList.get(3));
		int judgeNum = Integer.parseInt(paramList.get(4));
		int shortNum = Integer.parseInt(paramList.get(5)); 
		String type = paramList.get(6);
		int otherNum = Integer.parseInt(paramList.get(7));
		String str = "";
		if (choiceNum != 0)
			str += RandomUtils.push("选择题", RandomUtils.product(choiceNum,10001, new QuestionServiceImpl().getQuestionCounts("选择题")));
		if (judgeNum != 0)
			str += RandomUtils.push("判断题", RandomUtils.product(judgeNum,20001, new QuestionServiceImpl().getQuestionCounts("判断题")));
		if (shortNum != 0) 
			str += RandomUtils.push("简答题", RandomUtils.product(shortNum,30001, new QuestionServiceImpl().getQuestionCounts("简答题")));
		if (otherNum != 0)
			str += RandomUtils.push(type, RandomUtils.product(otherNum,40001, new QuestionServiceImpl().getQuestionCounts(type)));
		paper.setPaperId(paperId);
		paper.setPaperName(paperName);
		paper.setPaperCourse(paperCourse);
		paper.setPaperInfo(str);
		paperDao = new PaperDaoImpl();
		paperDao.addPaper(paper);
		return 0;
	}

	public int deletePaper(int paperId) {
		// TODO Auto-generated method stub
		paperDao = new PaperDaoImpl();
		return paperDao.deletePaper(paperId);
	}

	public List<Question> getPaperQuestion(int paperId) {
		paperDao = new PaperDaoImpl();
		return Analyze.subAnalyze(paperDao.analysis(paperId));
	}

}
