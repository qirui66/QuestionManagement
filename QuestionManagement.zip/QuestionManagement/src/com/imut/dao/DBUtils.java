package com.imut.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtils {

	public static String driver = "com.mysql.jdbc.Driver";
	public static String url = "jdbc:mysql://localhost:3306/QM?useUnicode=true&characterEncoding=UTF-8";
	public static String username = "root";
	public static String password = "sunhao5200.0";
	
	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	public static void close(Connection connection,PreparedStatement preparedStatement,ResultSet rs) {
		try {
			if (null != connection)
				connection.close();
			if (null != preparedStatement) 
				preparedStatement.close();
			if (null != rs) 
				rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
