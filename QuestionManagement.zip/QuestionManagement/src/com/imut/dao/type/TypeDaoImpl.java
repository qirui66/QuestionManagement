package com.imut.dao.type;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.imut.dao.DBUtils;
import com.imut.pojo.QuestionType;

public class TypeDaoImpl implements TypeDao{
	
	Connection connection = null;

	public List<QuestionType> allTypes() {
		// TODO Auto-generated method stub
		List<QuestionType> typeList = new ArrayList<QuestionType>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from questionType";
		ResultSet rs = null;
		QuestionType type = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				type = new QuestionType();
				type.setTypeId(rs.getInt("type_id"));
				type.setTypeName(rs.getString("type_name"));
				typeList.add(type);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return typeList;	
	}

	public int addType(QuestionType type) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "insert into questionType(type_id,type_name) values (?,?)";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, type.getTypeId());
			preparedStatement.setString(2, type.getTypeName());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return judge;
	}

	public int deleteType(int typeId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "delete from questionType where type_id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, typeId);
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return judge;
	}

	public int updateType(QuestionType type) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "update questionType set type_name = ? where type_id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, type.getTypeName());
			preparedStatement.setInt(2, type.getTypeId());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return judge;
	}

	public QuestionType getTypeById(int typeId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		String sql = "select * from questionType where type_id = ?";
		ResultSet rs = null;
		QuestionType type = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, typeId);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				type = new QuestionType();
				type.setTypeId(rs.getInt("type_id"));
				type.setTypeName(rs.getString("type_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return type;	
	}

}
