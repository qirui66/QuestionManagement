package com.imut.dao.course;

import java.util.List;

import com.imut.pojo.Course;

public interface CourseDao {
	
	Course getCourseById(int courseId);
	
	int getCourseCounts();
	
	List<Course> getCourseByName(String courseName,int index);
	
	List<Course> allCourses(int index);
	
	int addCourse(Course course);
	
	int deleteCourse(int courseId);
	
	int updateCourse(Course course);
}
