package com.imut.dao.course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.imut.dao.DBUtils;
import com.imut.pojo.Course;

public class CourseDaoImpl implements CourseDao{
	
	public static Connection connection = null;

	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from course where course_id = ?";
		Course course = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, courseId);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				course = new Course();
				course.setCourseId(rs.getInt("course_id"));
				course.setCourseName(rs.getString("course_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return course;	
	}

	public int getCourseCounts() {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select count(*) as total from course";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				count = rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return count;	
	}

	public List<Course> getCourseByName(String courseName, int index) {
		// TODO Auto-generated method stub
		List<Course> courseList = new ArrayList<Course>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from course where course_name like ? limit ?,10";
		ResultSet rs = null;
		Course course = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, "%" + courseName + "%");
			preparedStatement.setInt(2, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				course = new Course();
				course.setCourseId(rs.getInt("course_id"));
				course.setCourseName(rs.getString("course_name"));
				courseList.add(course);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return courseList;	
	}

	public List<Course> allCourses(int index) {
		// TODO Auto-generated method stub
		List<Course> courseList = new ArrayList<Course>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from course limit ?,10";
		ResultSet rs = null;
		Course course = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				course = new Course();
				course.setCourseId(rs.getInt("course_id"));
				course.setCourseName(rs.getString("course_name"));
				courseList.add(course);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return courseList;	
	}

	public int addCourse(Course course) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "insert into course(course_id,course_name) values (?,?)";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, course.getCourseId());
			preparedStatement.setString(2, course.getCourseName());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		
		return judge;
	}

	public int deleteCourse(int courseId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "delete from course where course_id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, courseId);
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return judge;
	}

	public int updateCourse(Course course) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "update course set course_name = ? where course_id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, course.getCourseName());
			preparedStatement.setInt(2, course.getCourseId());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		
		return judge;
	}



}
