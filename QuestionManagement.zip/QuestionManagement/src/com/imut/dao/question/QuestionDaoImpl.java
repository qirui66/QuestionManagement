package com.imut.dao.question;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.imut.dao.DBUtils;
import com.imut.pojo.Question;


public class QuestionDaoImpl implements QuestionDao{

	public static Connection connection = null;

	public int getQuestionCounts(String type) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select count(*) as total from question where type = ?";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, type);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				count = rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return count;	
	}

	public List<Question> getQuestionByType(String type,int index) {
		// TODO Auto-generated method stub
		List<Question>	qList = new ArrayList<Question>();
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from question where type = ? limit ?,10";
		Question question = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, type);
			preparedStatement.setInt(2, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				question = new Question();
				question.setCourse(rs.getString("course"));
				question.setLevel(rs.getString("level"));
				question.setQid(rs.getInt("qid"));
				question.setName(rs.getString("name"));
				question.setAnswer(rs.getString("answer"));
				question.setType(rs.getString("type"));
				qList.add(question);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return qList;	
	}

	public List<Question> getQuestionByName(String questionName, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Question> getQuestionByCourse(String courseName, int index) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Question> allQuestion(int index) {
		// TODO Auto-generated method stub
		List<Question>	qList = new ArrayList<Question>();
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from question limit ?,10";
		Question question = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				question = new Question();
				question.setCourse(rs.getString("course"));
				question.setLevel(rs.getString("level"));
				question.setQid(rs.getInt("qid"));
				question.setName(rs.getString("name"));
				question.setAnswer(rs.getString("answer"));
				question.setType(rs.getString("type"));
				qList.add(question);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return qList;
	}

	public int addQuestion(Question question) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		String sql = "insert into question(qid,name,level,course,answer,type) values (?,?,?,?,?,?)";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, question.getQid());
			preparedStatement.setString(2, question.getName());
			preparedStatement.setString(3, question.getLevel());
			preparedStatement.setString(4, question.getCourse());
			preparedStatement.setString(5, question.getAnswer());
			preparedStatement.setString(6, question.getType());
			count = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return count;	
	}

	public int deleteQuestion(int qid) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		String sql = "delete from question where qid = ?";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, qid);
			count = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return count;
	}

	public int deleteQuestionByCourse(String courseName) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		String sql = "delete from question where course = ?";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, courseName);
			count = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return count;
	}

	public int updateQuestion(Question question) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		String sql = "update question set name = ?,level = ?,course = ?,answer = ?,type = ? where qid = ?";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, question.getName());
			preparedStatement.setString(2, question.getLevel());
			preparedStatement.setString(3, question.getCourse());
			preparedStatement.setString(4, question.getAnswer());
			preparedStatement.setString(5, question.getType());
			preparedStatement.setInt(6, question.getQid());
			count = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return count;	
	}

	public Question getQuestionBy(int qid) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from question where qid = ?";
		Question question = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, qid);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				question = new Question();
				question.setCourse(rs.getString("course"));
				question.setLevel(rs.getString("level"));
				question.setQid(rs.getInt("qid"));
				question.setName(rs.getString("name"));
				question.setAnswer(rs.getString("answer"));
				question.setType(rs.getString("type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return question;	
	}



}
