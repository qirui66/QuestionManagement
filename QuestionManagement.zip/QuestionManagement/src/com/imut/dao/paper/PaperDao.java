package com.imut.dao.paper;

import java.util.List;

import com.imut.pojo.Paper;

public interface PaperDao {
	
	Paper getPaperById(int paperId);
	
	List<Paper> getPaperByName(String paperName);
	
	List<Paper> allPapers();
	
	int addPaper(Paper paper);
	
	int deletePaper(int paperId);
	
	List<String> analysis(int paperId);
}
