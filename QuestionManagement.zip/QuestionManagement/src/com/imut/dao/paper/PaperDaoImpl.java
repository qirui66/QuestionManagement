package com.imut.dao.paper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.imut.Utils.Analyze;
import com.imut.dao.DBUtils;
import com.imut.pojo.Paper;

public class PaperDaoImpl implements PaperDao{
	
	public static Connection connection;

	public Paper getPaperById(int paperId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from paper where paper_id = ?";
		Paper paper = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, paperId);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				paper = new Paper();
				paper.setPaperId(rs.getInt("paper_id"));
				paper.setPaperName(rs.getString("paper_name"));
				paper.setPaperInfo(rs.getString("paper_info"));
				paper.setPaperCourse(rs.getString("paper_course"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return paper;	
	}

	public List<Paper> getPaperByName(String paperName) {
		// TODO Auto-generated method stub
		List<Paper> paperList = new ArrayList<Paper>();
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from paper where paper_name = ?";
		Paper paper = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, paperName);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				paper = new Paper();
				paper.setPaperId(rs.getInt("paper_id"));
				paper.setPaperName(rs.getString("paper_name"));
				paper.setPaperInfo(rs.getString("paper_info"));
				paper.setPaperCourse(rs.getString("paper_course"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return paperList;
	}

	public List<Paper> allPapers() {
		// TODO Auto-generated method stub
		List<Paper> paperList = new ArrayList<Paper>();
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select * from paper";
		Paper paper = null;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				paper = new Paper();
				paper.setPaperId(rs.getInt("paper_id"));
				paper.setPaperName(rs.getString("paper_name"));
				paper.setPaperInfo(rs.getString("paper_info"));
				paper.setPaperCourse(rs.getString("paper_course"));
				paperList.add(paper);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return paperList;
	}

	public int addPaper(Paper paper) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int judge = 0;
		String sql = "insert into paper(paper_id,paper_name,paper_info,paper_course) values (?,?,?,?)";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, paper.getPaperId());
			preparedStatement.setString(2, paper.getPaperName());
			preparedStatement.setString(3, paper.getPaperInfo());
			preparedStatement.setString(4, paper.getPaperCourse());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return judge;
	}

	public int deletePaper(int paperId) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int judge = 0;
		String sql = "delete from paper where paper_id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, paperId);
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return judge;
	}
	
	public int deletePaperByName(String courseName) {
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int judge = 0;
		String sql = "delete from paper where paper_course = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, courseName);
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return judge;
		
	}

	public List<String> analysis(int paperId) {
		// TODO Auto-generated method stub
		Paper paper = new PaperDaoImpl().getPaperById(paperId);
		String info = paper.getPaperInfo();
		return Analyze.analyzing(info);
		
	}

}
