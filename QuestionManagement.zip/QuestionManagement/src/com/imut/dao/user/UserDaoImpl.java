package com.imut.dao.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.imut.dao.DBUtils;
import com.imut.pojo.User;

public class UserDaoImpl implements UserDao{

	public static Connection connection = null;
	
	public User getUser(String account) {
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		User user = null;
		String sql = "select * from user where account = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, account);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		
		return user;
	}

	public List<User> allUsers(int index) {
		List<User> userList = new ArrayList<User>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from user limit ?,10";
		ResultSet rs = null;
		User user = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return userList;
	}
	
	

	public int addUser(User user) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "insert into user(realname,account,password,phonenumber,identity) values (?,?,?,?,?)";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user.getRealname());
			preparedStatement.setString(2, user.getAccount());
			preparedStatement.setString(3, user.getPassword());
			preparedStatement.setString(4, user.getPhonenumber());
			preparedStatement.setString(5, user.getIdentity());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		
		return judge;	
		}

	public int deleteUser(int id) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "delete from user where id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		return judge;	}

	public int updateUser(User user) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		int judge = 0;
		String sql = "update user set realname = ?,account = ?,password = ?,phonenumber = ?,identity = ? where id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user.getRealname());
			preparedStatement.setString(2, user.getAccount());
			preparedStatement.setString(3, user.getPassword());
			preparedStatement.setString(4, user.getPhonenumber());
			preparedStatement.setString(5, user.getIdentity());
			preparedStatement.setInt(6, user.getId());
			judge = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, null);
		}
		
		return judge;
	}

	public int getUserCounts() {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		String sql = "select count(*) as total from user";
		int count = 0;
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				count = rs.getInt("total");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return count;
	}

	public List<User> getUsersByName(String name, int index) {
		// TODO Auto-generated method stub
		List<User> userList = new ArrayList<User>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from user where realname like ? limit ?,10";
		ResultSet rs = null;
		User user = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, "%" + name + "%");
			preparedStatement.setInt(2, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return userList;
	}

	public List<User> getUsersByAccount(String account, int index) {
		// TODO Auto-generated method stub
		List<User> userList = new ArrayList<User>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from user where account like ? limit ?,10";
		ResultSet rs = null;
		User user = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, "%" + account + "%");
			preparedStatement.setInt(2, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return userList;
	}

	public List<User> getUsersByIdentity(String identity, int index) {
		// TODO Auto-generated method stub
		List<User> userList = new ArrayList<User>();
		PreparedStatement preparedStatement = null;
		String sql = "select * from user where identity like ? limit ?,10";
		ResultSet rs = null;
		User user = null;
		connection = DBUtils.getConnection();
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, "%" + identity + "%");
			preparedStatement.setInt(2, index);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return userList;
	}

	public User getUserById(int id) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		User user = null;
		String sql = "select * from user where id = ?";
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setAccount(rs.getString("account"));
				user.setId(rs.getInt("id"));
				user.setIdentity(rs.getString("identity"));
				user.setPassword(rs.getString("password"));
				user.setPhonenumber(rs.getString("phonenumber"));
				user.setRealname(rs.getString("realname"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtils.close(connection, preparedStatement, rs);
		}
		return user;
	}

	
}
