package com.imut.dao.user;

import java.util.List;
import com.imut.pojo.User;

public interface UserDao {

	User getUser(String account);
	
	User getUserById(int id);
	
	int getUserCounts();
	
	List<User> getUsersByName(String name,int index);
	
	List<User> getUsersByAccount(String account,int index);
	
	List<User> getUsersByIdentity(String identity,int index);
	
	List<User> allUsers(int index);
	
	int addUser(User user);
	
	int deleteUser(int id);
	
	int updateUser(User user);
}
