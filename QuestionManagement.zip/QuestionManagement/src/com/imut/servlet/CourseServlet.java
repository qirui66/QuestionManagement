package com.imut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.pojo.Course;
import com.imut.service.course.CourseServiceImpl;

public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CourseServlet() {

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if (method.equals("search"))
			search(request,response);
		else if (method.equals("delete")) 
			delete(request,response);
		else if (method.equals("toUpdate"))
			toUpdate(request,response);
		else if (method.equals("update"))
			update(request,response);
		else if (method.equals("add"))
			add(request,response);
		else
			response.sendRedirect(request.getContextPath() + "/Welcome.jsp");
	}
	
	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String page = request.getParameter("pageNum");
		System.out.println(name);
		int pageNum = 1;
		if (page != null) 
			pageNum = Integer.parseInt(page);
		request.setAttribute("cList", new CourseServiceImpl().getCourseByName(name, pageNum));
		request.getRequestDispatcher("course.jsp").forward(request, response);
	}
	
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		new CourseServiceImpl().deleteCourse(id);
		response.sendRedirect(request.getContextPath() + "/CourseServlet?method=search&name=" + name);
	}
	
	public void toUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int id = Integer.parseInt(request.getParameter("id"));
		session.setAttribute("course", new CourseServiceImpl().getCourseById(id));
		response.sendRedirect("http://localhost:8080/QuestionManagement/course/courseUpdate.jsp");
	}
	
	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Course course = new Course();
		String name = request.getParameter("name");
		course.setCourseId(Integer.parseInt(request.getParameter("id")));
		course.setCourseName(name);
		new CourseServiceImpl().updateCourse(course);
		response.sendRedirect(request.getContextPath() + "/CourseServlet?method=search&name=" + name);
	}
	
	public void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Course course = new Course();
		String name = request.getParameter("name");
		course.setCourseId(Integer.parseInt(request.getParameter("id")));
		course.setCourseName(request.getParameter("name"));
		new CourseServiceImpl().addCourse(course);
		response.sendRedirect(request.getContextPath() + "/CourseServlet?method=search&name=" + name);
	}

}
