package com.imut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.pojo.Question;
import com.imut.service.course.CourseServiceImpl;
import com.imut.service.question.QuestionServiceImpl;
import com.imut.service.type.TypeServiceImpl;

public class QuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public QuestionServlet() {

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if (method.equals("type"))
			type(request,response);
		else if (method.equals("delete")) 
			delete(request,response);
		else if (method.equals("toUpdate"))
			toUpdate(request,response);
		else if (method.equals("update"))
			update(request,response);
		else if (method.equals("toAdd"))
			toAdd(request,response);
		else if (method.equals("add"))
			add(request,response);
		else
			response.sendRedirect(request.getContextPath() + "/Welcome.jsp");
	}
	
	public void type(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		String page = request.getParameter("pageNum");
		System.out.println("type = " + type);
		int pageNum = 1;
		if (page != null)
			pageNum = Integer.parseInt(page);
		request.setAttribute("qList", new QuestionServiceImpl().getQuestionByType(type, pageNum));
		request.getRequestDispatcher("question.jsp").forward(request, response);
	}
	
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int qid = Integer.parseInt(request.getParameter("id"));
		new QuestionServiceImpl().deleteQuestion(qid);
		String type = request.getParameter("type");
		response.sendRedirect(request.getContextPath() + "/QuestionServlet?method=type&type=" + type);
	}
	
	public void toUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int qid = Integer.parseInt(request.getParameter("id"));
		session.setAttribute("question", new QuestionServiceImpl().getQuestionBy(qid));
		session.setAttribute("cList", new CourseServiceImpl().getCourseByName("", 1));
		session.setAttribute("tList", new TypeServiceImpl().allTypes());
		response.sendRedirect(request.getContextPath() + "/question/questionUpdate.jsp");
	}
	
	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Question question = new Question();
		String type = request.getParameter("type");
		question.setQid(Integer.parseInt(request.getParameter("id")));
		question.setName(request.getParameter("name"));
		question.setLevel(request.getParameter("level"));
		question.setAnswer(request.getParameter("answer"));
		question.setCourse(request.getParameter("course"));
		question.setType(type);
		new QuestionServiceImpl().updateQuestion(question);
		System.out.println(type);
		response.sendRedirect(request.getContextPath() + "/QuestionServlet?method=type&type=" + type);
	}
	
	public void toAdd(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.setAttribute("cList", new CourseServiceImpl().getCourseByName("", 1));
		session.setAttribute("tList", new TypeServiceImpl().allTypes());
		response.sendRedirect(request.getContextPath() + "/question/addQuestion.jsp");
	}
	
	public void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Question question = new Question();
		String type = request.getParameter("type");
		question.setQid(Integer.parseInt(request.getParameter("qid")));
		question.setName(request.getParameter("name"));
		question.setLevel(request.getParameter("level"));
		question.setAnswer(request.getParameter("answer"));
		question.setCourse(request.getParameter("course"));
		question.setType(type);
		new QuestionServiceImpl().addQuestion(question);
		response.sendRedirect(request.getContextPath() + "/QuestionServlet?method=type&type=" + type);
	}

}
