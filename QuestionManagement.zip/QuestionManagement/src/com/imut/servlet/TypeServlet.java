package com.imut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.pojo.QuestionType;
import com.imut.service.type.TypeServiceImpl;

/**
 * Servlet implementation class TypeServlet
 */
public class TypeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TypeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String method = request.getParameter("method");
		if (method.equals("search"))
			search(request,response);
		else if (method.equals("add"))
			add(request,response);
		else if (method.equals("toUpdate"))
			toUpdate(request,response);
		else if (method.equals("update")) 
			update(request,response);
		else if (method.equals("delete"))
			delete(request,response);
		else
			search(request,response);
		
	}

	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("typeList", new TypeServiceImpl().allTypes());
		request.getRequestDispatcher("type.jsp").forward(request, response);
	}
	
	public void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		QuestionType type = new QuestionType();
		type.setTypeId(Integer.parseInt(request.getParameter("id")));
		type.setTypeName(request.getParameter("name"));
		new TypeServiceImpl().addType(type);
		response.sendRedirect(request.getContextPath() + "/TypeServlet?method=search");
	}
	
	public void toUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		int id = Integer.parseInt(request.getParameter("id"));
		session.setAttribute("type", new TypeServiceImpl().getTypeById(id));
		response.sendRedirect("http://localhost:8080/QuestionManagement/type/typeUpdate.jsp");
	}
	
	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException {
		QuestionType type = new QuestionType();
		type.setTypeId(Integer.parseInt(request.getParameter("id")));
		type.setTypeName(request.getParameter("name"));
		new TypeServiceImpl().updateType(type);
		response.sendRedirect(request.getContextPath() + "/TypeServlet?method=search");
	}
	
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		new TypeServiceImpl().deleteType(id);
		response.sendRedirect(request.getContextPath() + "/TypeServlet?method=search");
	}
}
