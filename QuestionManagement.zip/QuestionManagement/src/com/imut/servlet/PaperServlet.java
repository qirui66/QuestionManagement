package com.imut.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.service.course.CourseServiceImpl;
import com.imut.service.paper.PaperServiceImpl;
import com.imut.service.type.TypeServiceImpl;

public class PaperServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PaperServlet() {

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if (method.equals("search"))
			search(request,response);
		else if (method.equals("delete")) 
			delete(request,response);
		else if (method.equals("add"))
			add(request,response);
		else if (method.equals("view"))
			view(request,response);
		else if (method.equals("toAdd"))
			toAdd(request,response);
		else
			search(request,response);
	}
	
	public void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String content = request.getParameter("content");
		if (content != null)
			request.setAttribute("paperList", new PaperServiceImpl().getPaperByName(content));
		else
			request.setAttribute("paperList", new PaperServiceImpl().allPapers());
		request.getRequestDispatcher("paper.jsp").forward(request, response);
	}
	
	
	public void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String paperId = request.getParameter("id");
		String paperName = request.getParameter("name");
		String courseName = request.getParameter("course");
		String choiceNum = request.getParameter("choice");
		String judgeNum = request.getParameter("judge");
		String shortNum = request.getParameter("short");
		String type = request.getParameter("type");
		String otehrNum = request.getParameter("other");
		List<String> paramList = new ArrayList<String>();
		paramList.add(paperId);
		paramList.add(paperName);
		paramList.add(courseName);
		paramList.add(choiceNum);
		paramList.add(judgeNum);
		paramList.add(shortNum);
		paramList.add(type);
		paramList.add(otehrNum);
		System.out.println(paramList);
		new PaperServiceImpl().addPaper(paramList);
		response.sendRedirect(request.getContextPath() + "/PaperServlet?method=search");
	}
	
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		new PaperServiceImpl().deletePaper(id);
		response.sendRedirect(request.getContextPath() + "/PaperServlet?method=search");
	}
	
	public void view(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int paperId = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("qList", new PaperServiceImpl().getPaperQuestion(paperId));
		request.getRequestDispatcher("question.jsp").forward(request, response);
	}
	
	public void toAdd(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.setAttribute("cList", new CourseServiceImpl().getCourseByName("", 1));
		session.setAttribute("tList", new TypeServiceImpl().allTypes());
		response.sendRedirect(request.getContextPath() + "/paper/addPaper.jsp");
	}

}
