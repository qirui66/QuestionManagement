package com.imut.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.imut.Utils.Paging;
import com.imut.pojo.User;
import com.imut.service.user.UserServiceImpl;

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UserServlet() {
    	
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if (method.equals("search")) {
			searching(request,response);
		} else if (method.equals("toUpdate")) {
			toUpdate(request,response);
		} else if (method.equals("update")) {
			update(request,response);
		} else if (method.equals("add")) {
			add(request,response);
		} else if (method.equals("delete")) {
			delete(request,response);
		} else {
			response.sendRedirect(request.getContextPath() + "/UserServlet?method=search");
		}
	}
	
	public void searching(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String content = request.getParameter("content");
	    String mode = request.getParameter("msg");
	    String page = request.getParameter("pageNum");
	    int pageNum = 1;
	    int count = new UserServiceImpl().getUserCounts();
	    if (page != null) {
	        pageNum = Integer.parseInt(page);
	    }
	    System.out.println("content = " + content + page);
	    request.setAttribute("pageNum", pageNum);
	    request.setAttribute("count", count);
	    request.setAttribute("nowPage", Paging.pageCal(pageNum, count));
	    if (content != null) {
	        if (content.equals("")) 
	            request.setAttribute("userList", new UserServiceImpl().allUsers(pageNum));
	        else {
	            if (mode != null) {
	                if (mode.equals("realname"))
	                    request.setAttribute("userList", new UserServiceImpl().getUsersByName(content, pageNum));
	                if (mode.equals("account"))
	                    request.setAttribute("userList", new UserServiceImpl().getUsersByAccount(content, pageNum));
	                if (mode.equals("identity"))
	                    request.setAttribute("userList", new UserServiceImpl().getUsersByIdentity(content, pageNum));
	                if (mode.equals(""))
	                    request.setAttribute("userList", new UserServiceImpl().allUsers(pageNum));
	                request.setAttribute("mode", mode);
	            }
	            request.setAttribute("content", content);
	        }
	        request.getRequestDispatcher("user.jsp").forward(request,response);
	    } else {
	        request.setAttribute("userList", new UserServiceImpl().allUsers(pageNum));
	        request.getRequestDispatcher("user.jsp").forward(request, response);
	    }
	}
	
	public void toUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession();
		int id = Integer.parseInt(request.getParameter("id"));
		session.setAttribute("udpateUser", new UserServiceImpl().getUserById(id));
		response.sendRedirect("http://localhost:8080/QuestionManagement/user/userUpdate.jsp");
	}
	
	public void update(HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = new User();
		user.setAccount(request.getParameter("account"));
		user.setIdentity(request.getParameter("identity"));
		user.setPassword(request.getParameter("password"));
		user.setPhonenumber(request.getParameter("phonenumber"));
		user.setRealname(request.getParameter("realname"));
		user.setId(Integer.parseInt(request.getParameter("id")));
		new UserServiceImpl().updateUser(user);
		response.sendRedirect(request.getContextPath() + "/UserServlet?method=search");
	}
	
	public void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		new UserServiceImpl().deleteUser(id);
		response.sendRedirect(request.getContextPath() + "/UserServlet?method=search");
	}
	
	public void add(HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = new User();
		user.setAccount(request.getParameter("account"));
		user.setIdentity(request.getParameter("identity"));
		user.setPassword(request.getParameter("password"));
		user.setPhonenumber(request.getParameter("phonenumber"));
		user.setRealname(request.getParameter("realname"));
		new UserServiceImpl().addUser(user);
		response.sendRedirect(request.getContextPath() + "/UserServlet?method=search");
	}

}
