package com.imut.pojo;

public class ShortQuestion {

	private int shortId;
	private String name;
	private String answer;
	
	public ShortQuestion() {
		
	}
	
	public ShortQuestion(int shortId, String name, String answer) {
		super();
		this.shortId = shortId;
		this.name = name;
		this.answer = answer;
	}

	public int getShortId() {
		return shortId;
	}
	
	public void setShortId(int shortId) {
		this.shortId = shortId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAnswer() {
		return answer;
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
