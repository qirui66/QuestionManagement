package com.imut.pojo;

public class JudgeQuestion {

	private int judgeId;
	private String name;
	private String answer;
	
	public JudgeQuestion() {
		
	}
	
	public JudgeQuestion(int judgeId, String name, String answer) {
		super();
		this.judgeId = judgeId;
		this.name = name;
		this.answer = answer;
	}

	public int getJudgeId() {
		return judgeId;
	}
	
	public void setJudgeId(int judgeId) {
		this.judgeId = judgeId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getAnswer() {
		return answer;
	}
	
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
