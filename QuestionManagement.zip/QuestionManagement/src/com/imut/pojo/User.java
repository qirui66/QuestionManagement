package com.imut.pojo;

public class User {
	private int id;
	private String realname;
	private String account;
	private String password;
	private String phonenumber;
	private String identity;
	
	public User() {
		
	}
	
	public User(int id, String realname, String account, String password, String phonenumber, String identity) {
		this.id = id;
		this.realname = realname;
		this.account = account;
		this.password = password;
		this.phonenumber = phonenumber;
		this.identity = identity;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getRealname() {
		return realname;
	}
	
	public void setRealname(String realname) {
		this.realname = realname;
	}
	
	public String getAccount() {
		return account;
	}
	
	public void setAccount(String account) {
		this.account = account;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPhonenumber() {
		return phonenumber;
	}
	
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	public String getIdentity() {
		return identity;
	}
	
	public void setIdentity(String identity) {
		this.identity = identity;
	}

	
	
	
}
