package com.imut.pojo;

public class Paper {

	private int paperId;
	private String paperName;
	private String paperCourse;
	private String paperInfo;
	
	public Paper() {
		
	}
	
	public Paper(int paperId, String paperName, String paperCourse, String createTime, String createTeacher,
			String paperInfo) {
		this.paperId = paperId;
		this.paperName = paperName;
		this.paperCourse = paperCourse;
		this.paperInfo = paperInfo;
	}

	public int getPaperId() {
		return paperId;
	}

	public void setPaperId(int paperId) {
		this.paperId = paperId;
	}

	public String getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName = paperName;
	}

	public String getPaperCourse() {
		return paperCourse;
	}

	public void setPaperCourse(String paperCourse) {
		this.paperCourse = paperCourse;
	}

	public String getPaperInfo() {
		return paperInfo;
	}

	public void setPaperInfo(String paperInfo) {
		this.paperInfo = paperInfo;
	}
	
	
	
	
}
