package com.imut.pojo;

public class OtherQuestion {

	private int otherId;
	private String name;
	private String answer;

	public OtherQuestion() {

	}

	public OtherQuestion(int otherId, String name, String answer) {
		super();
		this.otherId = otherId;
		this.name = name;
		this.answer = answer;
	}

	public int getOtherId() {
		return otherId;
	}

	public void setOtherId(int otherId) {
		this.otherId = otherId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
	
}
